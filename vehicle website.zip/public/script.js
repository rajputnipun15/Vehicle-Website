// Navigation scroll effect
const nav = document.querySelector(".nav")

window.addEventListener("scroll", () => {
  if (window.scrollY > 100) {
    nav.classList.add("scrolled")
  } else {
    nav.classList.remove("scrolled")
  }
})

// 3D Tilt Effect for Cards
const tiltCards = document.querySelectorAll(".tilt-card")

tiltCards.forEach((card) => {
  card.addEventListener("mousemove", handleTilt)
  card.addEventListener("mouseleave", resetTilt)
})

function handleTilt(e) {
  const card = e.currentTarget
  const rect = card.getBoundingClientRect()
  const x = e.clientX - rect.left
  const y = e.clientY - rect.top

  const centerX = rect.width / 2
  const centerY = rect.height / 2

  const rotateX = ((y - centerY) / centerY) * 10
  const rotateY = ((centerX - x) / centerX) * 10

  card.style.transform = `perspective(1000px) rotateX(${rotateX}deg) rotateY(${rotateY}deg) scale3d(1.02, 1.02, 1.02)`
}

function resetTilt(e) {
  const card = e.currentTarget
  card.style.transform = "perspective(1000px) rotateX(0) rotateY(0) scale3d(1, 1, 1)"
}

// Showcase Vehicle 3D Rotation
const showcaseVehicle = document.getElementById("showcaseVehicle")
let isDragging = false
let startX = 0
let currentRotation = 0

if (showcaseVehicle) {
  showcaseVehicle.addEventListener("mousedown", startDrag)
  showcaseVehicle.addEventListener("mousemove", drag)
  showcaseVehicle.addEventListener("mouseup", stopDrag)
  showcaseVehicle.addEventListener("mouseleave", stopDrag)

  // Touch events for mobile
  showcaseVehicle.addEventListener("touchstart", startDragTouch)
  showcaseVehicle.addEventListener("touchmove", dragTouch)
  showcaseVehicle.addEventListener("touchend", stopDrag)
}

function startDrag(e) {
  isDragging = true
  startX = e.clientX
}

function startDragTouch(e) {
  isDragging = true
  startX = e.touches[0].clientX
}

function drag(e) {
  if (!isDragging) return

  const deltaX = e.clientX - startX
  const rotationDelta = deltaX * 0.5

  showcaseVehicle.style.transform = `rotateY(${currentRotation + rotationDelta}deg)`
}

function dragTouch(e) {
  if (!isDragging) return

  const deltaX = e.touches[0].clientX - startX
  const rotationDelta = deltaX * 0.5

  showcaseVehicle.style.transform = `rotateY(${currentRotation + rotationDelta}deg)`
}

function stopDrag() {
  if (!isDragging) return

  isDragging = false
  const transform = showcaseVehicle.style.transform
  const match = transform.match(/rotateY$$([^)]+)$$/)

  if (match) {
    currentRotation = Number.parseFloat(match[1])
  }
}

// Parallax Effect for Future Section
const futureParallaxBg = document.querySelector(".future-parallax-bg")

if (futureParallaxBg) {
  window.addEventListener("scroll", () => {
    const scrollPosition = window.scrollY
    const futureSection = document.querySelector(".future-section")

    if (futureSection) {
      const rect = futureSection.getBoundingClientRect()

      if (rect.top < window.innerHeight && rect.bottom > 0) {
        const offset = (rect.top - window.innerHeight) * 0.3
        futureParallaxBg.style.transform = `translateY(${offset}px)`
      }
    }
  })
}

// Smooth Scroll Animation Observer
const observerOptions = {
  threshold: 0.2,
  rootMargin: "0px 0px -100px 0px",
}

const observer = new IntersectionObserver((entries) => {
  entries.forEach((entry) => {
    if (entry.isIntersecting) {
      entry.target.classList.add("fade-in")
      observer.unobserve(entry.target)
    }
  })
}, observerOptions)

// Observe elements for scroll animations
document.querySelectorAll(".glass-card, .feature-card, .section-header").forEach((el) => {
  observer.observe(el)
})

// Newsletter Form
const newsletterForm = document.querySelector(".newsletter-form")

if (newsletterForm) {
  newsletterForm.addEventListener("submit", (e) => {
    e.preventDefault()
    const input = newsletterForm.querySelector(".newsletter-input")
    const email = input.value

    if (email) {
      // Show success message (in production, this would send to a server)
      alert(`Thank you for subscribing with ${email}! We'll keep you updated on the future of autonomous luxury.`)
      input.value = ""
    }
  })
}

// Smooth scroll for navigation links
document.querySelectorAll('a[href^="#"]').forEach((anchor) => {
  anchor.addEventListener("click", function (e) {
    e.preventDefault()
    const target = document.querySelector(this.getAttribute("href"))

    if (target) {
      const offsetTop = target.offsetTop - 80
      window.scrollTo({
        top: offsetTop,
        behavior: "smooth",
      })
    }
  })
})

// Dynamic gradient movement on hero
const heroBackground = document.querySelector(".hero-background")

if (heroBackground) {
  document.addEventListener("mousemove", (e) => {
    const x = (e.clientX / window.innerWidth) * 100
    const y = (e.clientY / window.innerHeight) * 100

    heroBackground.style.background = `radial-gradient(circle at ${x}% ${y}%, rgba(0, 212, 255, 0.15) 0%, transparent 50%)`
  })
}

// Performance: Reduce animations on low-end devices
if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
  document.querySelectorAll("*").forEach((el) => {
    el.style.animation = "none"
    el.style.transition = "none"
  })
}

console.log("[v0] AIVO luxury website loaded successfully")
